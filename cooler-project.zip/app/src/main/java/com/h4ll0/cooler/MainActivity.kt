package com.h4ll0.cooler

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Red = Color(0xFFE0262E)
private val SELF = "com.h4ll0.cooler"
private val IGNORE = setOf(SELF, "android", "com.android.systemui", "com.android.launcher3")

data class RunningApp(val pkg: String, val label: String, var checked: Boolean = true)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Color(0xFF0D0A0A), surface = Color(0xFF191212))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }

    fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    fun batteryTemp(): Float? {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
        return if (t <= 0) null else t / 10f
    }
    fun batteryLevel(): Int {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (lvl < 0 || sc <= 0) -1 else (lvl * 100 / sc)
    }
    fun ramInfo(): Pair<Long, Long> {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        return (mi.totalMem - mi.availMem) to mi.totalMem
    }
    fun runningApps(): List<RunningApp> {
        val out = mutableListOf<RunningApp>()
        try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis(); val begin = end - 60 * 60 * 1000
            val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, begin, end)
            val pm = packageManager
            val seen = linkedSetOf<String>()
            stats.sortedByDescending { it.lastTimeUsed }.forEach { s ->
                if (s.packageName in IGNORE || s.packageName in seen) return@forEach
                seen += s.packageName
                try {
                    val ai = pm.getApplicationInfo(s.packageName, 0)
                    out += RunningApp(s.packageName, pm.getApplicationLabel(ai).toString())
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
        return out.take(25)
    }
    fun killApps(pkgs: List<String>): Int {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        var n = 0
        pkgs.forEach { runCatching { am.killBackgroundProcesses(it); n++ } }
        return n
    }
}

@Composable
fun App() {
    val a = androidx.compose.ui.platform.LocalContext.current as MainActivity
    var usageOk by remember { mutableStateOf(a.hasUsage()) }
    var temp by remember { mutableStateOf(a.batteryTemp()) }
    var level by remember { mutableStateOf(a.batteryLevel()) }
    var ram by remember { mutableStateOf(a.ramInfo()) }
    var apps by remember { mutableStateOf(if (usageOk) a.runningApps() else emptyList()) }
    var closedMsg by remember { mutableStateOf("") }
    val lUsage = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) {
        usageOk = a.hasUsage(); if (usageOk) apps = a.runningApps()
    }
    fun refresh() { temp = a.batteryTemp(); level = a.batteryLevel(); ram = a.ramInfo(); if (usageOk) apps = a.runningApps(); closedMsg = "" }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Cooler", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Red, modifier = Modifier.weight(1f))
            TextButton({ refresh() }) { Text("Refresh") }
        }
        Spacer(Modifier.height(10.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                val t = temp
                Row {
                    Text(if (t != null) "🌡 ${"%.1f".format(t)}°C" else "🌡 Gak tersedia", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        color = if (t != null && t >= 42f) Color(0xFFFF7B7B) else Color.White, modifier = Modifier.weight(1f))
                    Text("🔋 $level%", fontSize = 20.sp)
                }
                Spacer(Modifier.height(6.dp))
                val (used, total) = ram
                val pct = if (total > 0) used.toFloat() / total else 0f
                Text("RAM: ${used / 1024 / 1024} MB / ${total / 1024 / 1024} MB", color = Color.Gray, fontSize = 13.sp)
                LinearProgressIndicator({ pct }, Modifier.fillMaxWidth().padding(top = 4.dp))
                if (t != null && t >= 42f) Text("Lumayan panas, coba tutup app di bawah dulu.", color = Color(0xFFFF7B7B), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
        Spacer(Modifier.height(14.dp))

        if (!usageOk) {
            Text("Izinkan Usage Access buat lihat app yang lagi jalan di background:", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Button({ lUsage.launch(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }) { Text("Buka Usage Access") }
        } else {
            Text("App aktif di background (centang yang mau ditutup):", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(apps, key = { it.pkg }) { ra ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(ra.checked, { ra.checked = it; apps = apps.toList() })
                        Text(ra.label, Modifier.weight(1f))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            if (closedMsg.isNotEmpty()) Text(closedMsg, color = Color(0xFF7CFF8C), fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
            Button({
                val sel = apps.filter { it.checked }.map { it.pkg }
                val n = a.killApps(sel)
                closedMsg = "$n app ditutup dari background"
                apps = a.runningApps()
            }, Modifier.fillMaxWidth()) { Text("Tutup app yang dicentang") }
            Text("Catatan: Android modern sering otomatis nyalain lagi app yang penting, jadi hasilnya gak selalu permanen.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}
